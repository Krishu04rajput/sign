"""python scripts/predict.py path/to/image.jpg"""
import sys, json, cv2
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from vision.pipeline import analyze
r = analyze(cv2.imread(sys.argv[1])); r.pop("landmarks"); print(json.dumps(r, indent=2))
