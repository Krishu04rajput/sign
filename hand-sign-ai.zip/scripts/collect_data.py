"""Webcam collection: python scripts/collect_data.py hello   (SPACE=save, Q=quit)"""
import sys, time, cv2
from pathlib import Path
sign = sys.argv[1]; out = Path(__file__).resolve().parents[1] / "dataset" / sign; out.mkdir(parents=True, exist_ok=True)
cap = cv2.VideoCapture(0); n = len(list(out.glob("*.jpg")))
while True:
    ok, f = cap.read()
    if not ok: break
    v = f.copy(); cv2.putText(v, f"{sign}: {n} saved | SPACE save, Q quit", (10, 30), 0, 0.7, (255, 255, 0), 2)
    cv2.imshow("collect", v); k = cv2.waitKey(1) & 255
    if k == 32: cv2.imwrite(str(out / f"{int(time.time()*1000)}.jpg"), f); n += 1
    if k == ord("q"): break
