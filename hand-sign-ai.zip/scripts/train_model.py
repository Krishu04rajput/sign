"""Extract landmarks from dataset/<sign_id>/*.jpg|png|webp, train, evaluate, export."""
import sys, pickle, cv2, numpy as np
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "backend"))
from vision.pipeline import normalize, detect, MODEL_PATH
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

X, y = [], []
for d in sorted((ROOT / "dataset").iterdir()):
    if not d.is_dir(): continue
    n = 0
    for f in d.iterdir():
        if f.suffix.lower() not in {".jpg", ".jpeg", ".png", ".webp"}: continue
        img = cv2.imread(str(f)); res = detect(img) if img is not None else None
        if res and res.multi_hand_landmarks and len(res.multi_hand_landmarks) == 1:
            X.append(normalize([[p.x, p.y, p.z] for p in res.multi_hand_landmarks[0].landmark])); y.append(d.name); n += 1
    print(f"{d.name}: {n} usable images")
if len(set(y)) < 2: sys.exit("Need images for at least 2 signs in dataset/<sign_id>/ (see README).")
X, y = np.array(X), np.array(y)
strat = y if min(np.unique(y, return_counts=True)[1]) >= 2 else None
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=strat)
print(classification_report(yte, RandomForestClassifier(n_estimators=300, random_state=42).fit(Xtr, ytr).predict(Xte), zero_division=0))
clf = RandomForestClassifier(n_estimators=300, random_state=42).fit(X, y)
MODEL_PATH.parent.mkdir(exist_ok=True)
pickle.dump({"clf": clf}, open(MODEL_PATH, "wb")); print("Saved", MODEL_PATH)
