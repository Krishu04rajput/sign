"""Hold-out evaluation report is printed by train_model.py."""
import runpy, pathlib
runpy.run_path(str(pathlib.Path(__file__).with_name("train_model.py")))
