"""OpenCV preprocessing -> MediaPipe Hands -> normalization -> classifier."""
import os, time, pickle, threading
from pathlib import Path
import cv2, numpy as np, mediapipe as mp
from signs import LOOKUP

MODEL_PATH = Path(__file__).resolve().parents[1] / "models" / "hand_sign_model.pkl"
THRESH = float(os.getenv("CONF_THRESHOLD", "0.6"))
BLUR_MIN = 30.0
_hands = mp.solutions.hands.Hands(static_image_mode=True, max_num_hands=2, min_detection_confidence=0.5)
_lock = threading.Lock()
_model = {"mtime": None, "obj": None}

def normalize(pts):
    """(21,3) -> 63 features, wrist-relative and scale-invariant."""
    a = np.asarray(pts, float); a = a - a[0]
    return (a / (np.abs(a).max() or 1.0)).flatten()

def load_model():
    if not MODEL_PATH.exists():
        _model.update(mtime=None, obj=None); return None
    m = MODEL_PATH.stat().st_mtime
    if _model["mtime"] != m:
        with open(MODEL_PATH, "rb") as f: _model.update(obj=pickle.load(f), mtime=m)
    return _model["obj"]

def detect(bgr):
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    with _lock: return _hands.process(rgb)

def analyze(bgr):
    t0 = time.time()
    out = {"success": False, "hand_detected": False, "landmarks": [], "bbox": None}
    fin = lambda d: {**d, "processing_time": round(time.time() - t0, 3)}
    if cv2.Laplacian(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY), cv2.CV_64F).var() < BLUR_MIN:
        out["warning"] = "Image looks blurry."
    res = detect(bgr)
    n = len(res.multi_hand_landmarks or [])
    if n == 0: return fin({**out, "error": "no_hand", "message": "No hand detected. Upload an image with a clearly visible hand."})
    if n > 1: return fin({**out, "error": "multiple_hands", "message": "Multiple hands detected. Use one hand per image."})
    pts = np.array([[p.x, p.y, p.z] for p in res.multi_hand_landmarks[0].landmark])
    out.update(hand_detected=True, landmarks=pts.tolist(),
               detection_confidence=float(res.multi_handedness[0].classification[0].score),
               bbox=[float(pts[:, 0].min()), float(pts[:, 1].min()), float(pts[:, 0].max()), float(pts[:, 1].max())])
    if (pts[:, :2] < 0.0).any() or (pts[:, :2] > 1.0).any():
        return fin({**out, "error": "partial_hand", "message": "Hand is partly outside the image. Keep the whole hand in frame."})
    model = load_model()
    if model is None:
        return fin({**out, "error": "model_unavailable", "message": "MODEL NOT TRAINED. Run: python scripts/train_model.py"})
    try:
        proba = model["clf"].predict_proba([normalize(pts)])[0]
        i = int(np.argmax(proba)); cid = str(model["clf"].classes_[i]); conf = float(proba[i])
    except Exception as e:
        return fin({**out, "error": "prediction_failed", "message": f"Prediction failed: {e}"})
    info = LOOKUP.get(cid, {"label": cid.upper(), "category": "custom", "description": ""})
    out.update(label=info["label"], id=cid, category=info["category"], description=info["description"], confidence=conf)
    if conf < THRESH:
        out.update(error="low_confidence", message="SIGN NOT CONFIDENTLY RECOGNIZED")
    else: out["success"] = True
    return fin(out)
