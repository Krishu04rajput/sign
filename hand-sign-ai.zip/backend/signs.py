"""Sign registry. To add a sign: add to EXTRA, make dataset/<id>/, retrain."""
import string
ALPHA = dict(zip(string.ascii_uppercase, "Fist + Thumb|Flat Hand|Curved|Index Up|Fingers In|Circle|Pointing|Two Fingers|Pinky Up|Pinky + Thumb|Index + Middle|L Shape|Three Down|Two Down|Circle|Point Down|Point Down + Thumb|Index + Middle|Fist|Thumb Between|Two Up|Two Fingers|Three Up|Hooked Index|Pinky + Thumb|Z Shape".split("|")))
NUMS = dict(zip("0123456789", "Circle|Index Up|Index + Middle|Three Up|Four Up|Open Palm|Thumb + Pinky|Thumb + Index + Middle|Thumb + Index|Thumb + Four".split("|")))
PHRASES = {"hello":("Hello","Wave Hand"),"good":("Good","Thumbs Up"),"yes":("Yes","Nod / Thumbs Up"),"no":("No","Shake / Index No"),
 "please":("Please","Hands Together"),"thank_you":("Thank You","Hand on Chest"),"sorry":("Sorry","Hands Together"),"im_fine":("I'm Fine","OK Sign"),
 "ok":("OK","OK Sign"),"love":("Love","Heart Sign"),"stop":("Stop","Palm Forward"),"come_here":("Come Here","Curl Fingers"),"wait":("Wait","Palm Up"),
 "go":("Go","Point Forward"),"help":("Help","Open Hands Up"),"danger":("Danger","Cross Arms"),"eat":("Eat","Hand to Mouth"),"drink":("Drink","Hand to Mouth"),
 "sleep":("Sleep","Hand on Cheek"),"goodbye":("Goodbye","Wave")}
EXTRA = {}  # id: (label, description, category)
def all_signs():
    s = [dict(id=k, label=k, category="alphabet", description=v) for k, v in ALPHA.items()]
    s += [dict(id=k, label=k, category="number", description=v) for k, v in NUMS.items()]
    s += [dict(id=k, label=l.upper(), category="phrase", description=d) for k, (l, d) in PHRASES.items()]
    s += [dict(id=k, label=l.upper(), category=c, description=d) for k, (l, d, c) in EXTRA.items()]
    return s
LOOKUP = {s["id"]: s for s in all_signs()}
