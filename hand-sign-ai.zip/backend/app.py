import sys, cv2, numpy as np
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse, FileResponse
from signs import all_signs
from vision import pipeline

app = FastAPI(title="HandVision AI")
FRONT = Path(__file__).resolve().parents[1] / "frontend"
OK_TYPES = {"image/png", "image/jpeg", "image/webp"}

def err(code, msg, status): return JSONResponse({"success": False, "error": code, "message": msg}, status)

@app.get("/")
def index(): return FileResponse(FRONT / "index.html")

@app.get("/api/signs")
def signs(): return {"signs": all_signs()}

@app.get("/api/status")
def status():
    m = pipeline.load_model()
    return {"model_loaded": m is not None, "classes": len(m["clf"].classes_) if m else 0, "threshold": pipeline.THRESH}

@app.post("/api/analyze")
async def analyze(image: UploadFile = File(...)):
    try:
        if image.content_type not in OK_TYPES: return err("unsupported_format", "Use PNG, JPG or WEBP.", 415)
        data = await image.read()
        if len(data) > 8 * 1024 * 1024: return err("too_large", "Image over 8 MB.", 413)
        img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if img is None: return err("invalid_image", "Could not read image.", 400)
        return pipeline.analyze(img)
    except Exception as e:
        return err("internal", str(e), 500)
