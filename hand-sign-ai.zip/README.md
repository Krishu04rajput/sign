# HandVision AI — local hand-sign recognition
Upload an image **or use your webcam** → MediaPipe Hands (21 landmarks) → wrist-relative normalization → RandomForest → sign + confidence + landmark overlay. Everything runs locally; no API keys.

## Setup (Python 3.9–3.11 recommended for MediaPipe)
```
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
## Run (backend serves the frontend)
```
uvicorn backend.app:app --app-dir . --reload     # or: cd backend && uvicorn app:app --reload
```
Open http://127.0.0.1:8000. Camera access works on localhost.

## Dataset & training
Folders under `dataset/` are the sign ids (`A`, `7`, `hello`, `thank_you`, `im_fine`, `come_here` ...).
```
python scripts/collect_data.py hello      # webcam: SPACE saves, Q quits
python scripts/train_model.py             # extracts landmarks, prints hold-out report, saves backend/models/hand_sign_model.pkl
python scripts/evaluate_model.py          # same report
python scripts/predict.py some.jpg        # CLI prediction
```
Aim for 50+ varied images per sign. Restart not needed: the backend reloads the model file when it changes.

## Add a new sign
Add an entry to `EXTRA` in `backend/signs.py` -> `(label, description, category)`, create `dataset/<id>/`, add images, retrain.

## Notes / limits
- Low-confidence threshold: env var `CONF_THRESHOLD` (default 0.6).
- Static landmarks cannot capture motion (Hello wave, No shake, Thank You) or two-hand/body signs (Please, Help, Danger, Sleep). These are classified on a single static hand pose only; the backend rejects multi-hand images.
- Troubleshooting: if `mediapipe` won't install, use Python 3.10/3.11; if the camera is blocked, allow it in browser site settings.
